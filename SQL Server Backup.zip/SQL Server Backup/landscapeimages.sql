-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql107.byetcluster.com
-- Generation Time: Aug 11, 2024 at 12:00 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_37049035_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `landscapeimages`
--

CREATE TABLE `landscapeimages` (
  `id` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `upload_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `landscapeimages`
--

INSERT INTO `landscapeimages` (`id`, `filename`, `upload_time`) VALUES
(10, 'landscapeuploads/landscape4.jpg', '2024-08-10 19:40:47'),
(11, 'landscapeuploads/landscape5.jpg', '2024-08-10 19:41:22'),
(9, 'landscapeuploads/landscape3.jpg', '2024-08-10 19:40:22'),
(7, 'landscapeuploads/landscape1.jpg', '2024-08-10 19:39:13'),
(8, 'landscapeuploads/landscape2.jpg', '2024-08-10 19:39:57'),
(12, 'landscapeuploads/landscape6.jpg', '2024-08-10 19:42:19'),
(13, 'landscapeuploads/landscape7.jpg', '2024-08-10 19:42:48'),
(14, 'landscapeuploads/landscape8.jpg', '2024-08-10 19:44:08'),
(15, 'landscapeuploads/landscape9.jpg', '2024-08-10 19:45:02'),
(16, 'landscapeuploads/landscape10.jpg', '2024-08-10 19:45:16'),
(17, 'landscapeuploads/landscape11.jpg', '2024-08-10 19:45:34'),
(18, 'landscapeuploads/landscape12.jpg', '2024-08-10 19:45:46'),
(19, 'landscapeuploads/landscape13.jpg', '2024-08-10 19:46:02');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `landscapeimages`
--
ALTER TABLE `landscapeimages`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `landscapeimages`
--
ALTER TABLE `landscapeimages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
