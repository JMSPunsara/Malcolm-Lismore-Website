-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql107.byetcluster.com
-- Generation Time: Aug 11, 2024 at 12:00 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_37049035_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `subscribers`
--

CREATE TABLE `subscribers` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subscribe_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subscribers`
--

INSERT INTO `subscribers` (`id`, `email`, `subscribe_time`) VALUES
(1, 'a58322329@gmail.com', '2024-08-05 17:26:41'),
(2, 'shahaniresh@outlook.com', '2024-08-05 17:32:09'),
(3, 'shashinpunsaraebay@gmail.com', '2024-08-05 17:35:53'),
(4, 'kesaragayashaan@yahoo.com', '2024-08-05 17:38:27'),
(5, 'punsara649@gmail.com', '2024-08-05 17:46:09'),
(6, 'E154631@esoft.academy', '2024-08-05 17:52:45'),
(7, 'shahaniresh2003@outlook.com', '2024-08-06 12:56:25'),
(8, 'admin@far1.onmicrosoft.com', '2024-08-06 12:59:43'),
(9, 'shashinpunsaraebay@gmail.com', '2024-08-06 14:59:23'),
(10, 'ajithironworks71@gmail.com', '2024-08-06 14:59:54'),
(11, 'admin2000@far1.onmicrosoft.com', '2024-08-07 11:16:45'),
(12, 'sahandevinda@gmail.com', '2024-08-07 11:18:14'),
(13, 'shahaniresh2003@outlook.com', '2024-08-08 14:30:49'),
(14, 'tharinduwijwthilake@gmail.com', '2024-08-08 19:41:10'),
(15, 'ajithkumara@gmail.com', '2024-08-09 03:56:39'),
(16, 'tharushasewindara2003@outlook.com', '2024-08-09 18:08:24');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `subscribers`
--
ALTER TABLE `subscribers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `subscribers`
--
ALTER TABLE `subscribers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
