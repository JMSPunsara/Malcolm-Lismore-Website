-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql107.byetcluster.com
-- Generation Time: Aug 11, 2024 at 12:01 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_37049035_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `wildlifeimages`
--

CREATE TABLE `wildlifeimages` (
  `id` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `upload_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wildlifeimages`
--

INSERT INTO `wildlifeimages` (`id`, `filename`, `upload_time`) VALUES
(7, 'wildlifeuploads/pexels-hendrikcornelissen-2862070.jpg', '2024-08-11 03:06:48'),
(5, 'wildlifeuploads/pexels-leonardo-jarro-204864-633437.jpg', '2024-08-11 03:06:34'),
(6, 'wildlifeuploads/pexels-pixabay-66898.jpg', '2024-08-11 03:06:41'),
(8, 'wildlifeuploads/pexels-pixabay-247373.jpg', '2024-08-11 03:06:57'),
(9, 'wildlifeuploads/pexels-pixabay-52717.jpg', '2024-08-11 03:07:17'),
(10, 'wildlifeuploads/pexels-pixabay-460775.jpg', '2024-08-11 03:07:26'),
(11, 'wildlifeuploads/pexels-couleur-2317904.jpg', '2024-08-11 03:07:46'),
(12, 'wildlifeuploads/pexels-frans-van-heerden-201846-631292.jpg', '2024-08-11 03:07:54'),
(13, 'wildlifeuploads/pexels-pixabay-33045.jpg', '2024-08-11 03:08:07'),
(14, 'wildlifeuploads/pexels-pixabay-460223.jpg', '2024-08-11 03:08:26'),
(15, 'wildlifeuploads/pexels-andreas-barth-89047-1131774.jpg', '2024-08-11 03:08:33'),
(16, 'wildlifeuploads/pexels-andre-mouton-1207875.jpg', '2024-08-11 03:08:42'),
(17, 'wildlifeuploads/pexels-pixabay-36762.jpg', '2024-08-11 03:08:50'),
(18, 'wildlifeuploads/pexels-pixabay-70080.jpg', '2024-08-11 03:09:18'),
(19, 'wildlifeuploads/pexels-creativebin-38994-135940.jpg', '2024-08-11 03:09:26'),
(20, 'wildlifeuploads/pexels-hsapir-1054655.jpg', '2024-08-11 03:09:39'),
(21, 'wildlifeuploads/pexels-pixabay-46254.jpg', '2024-08-11 03:09:46'),
(22, 'wildlifeuploads/pexels-belle-co-99483-847393.jpg', '2024-08-11 03:09:59'),
(23, 'wildlifeuploads/pexels-pixabay-45853.jpg', '2024-08-11 03:10:07'),
(24, 'wildlifeuploads/pexels-pixabay-247376.jpg', '2024-08-11 03:10:14'),
(25, 'wildlifeuploads/pexels-monique-laats-230726-733090.jpg', '2024-08-11 03:10:20'),
(26, 'wildlifeuploads/pexels-thomas-b-270703-814898.jpg', '2024-08-11 03:10:28'),
(27, 'wildlifeuploads/pexels-pixabay-357159.jpg', '2024-08-11 03:10:35');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wildlifeimages`
--
ALTER TABLE `wildlifeimages`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wildlifeimages`
--
ALTER TABLE `wildlifeimages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
