-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql107.byetcluster.com
-- Generation Time: Aug 10, 2024 at 11:54 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_37049035_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`, `email`, `created_at`) VALUES
(1, 'Malcolm Lismore', '$2y$10$ll/0TfretvHtGcin0DyqzOKJdeTEI4G5OablDft4DdbEQVEXBfK5i', 'malcolmlismore@gmail.com', '2024-08-08 19:00:34');

-- --------------------------------------------------------

--
-- Table structure for table `coastalimages`
--

CREATE TABLE `coastalimages` (
  `id` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `upload_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `coastalimages`
--

INSERT INTO `coastalimages` (`id`, `filename`, `upload_time`) VALUES
(5, 'coastaluploads/pexels-orlovamaria-4913436.jpg', '2024-08-11 02:29:43'),
(6, 'coastaluploads/pexels-therato-3610763.jpg', '2024-08-11 02:29:51'),
(4, 'coastaluploads/pexels-timmossholder-2969405.jpg', '2024-08-11 02:29:15'),
(7, 'coastaluploads/pexels-pixabay-532891.jpg', '2024-08-11 02:30:05'),
(8, 'coastaluploads/pexels-therato-3451757.jpg', '2024-08-11 02:31:00'),
(9, 'coastaluploads/pexels-inspiredimages-133193.jpg', '2024-08-11 02:31:29'),
(10, 'coastaluploads/pexels-tirachard-kumtanom-112571-584302.jpg', '2024-08-11 02:31:47'),
(11, 'coastaluploads/pexels-therato-3384695.jpg', '2024-08-11 02:32:24'),
(12, 'coastaluploads/pexels-lucianphotography-3566139.jpg', '2024-08-11 02:32:56'),
(13, 'coastaluploads/pexels-miroalt-176383.jpg', '2024-08-11 02:33:18'),
(14, 'coastaluploads/pexels-pixabay-358223.jpg', '2024-08-11 02:33:31'),
(15, 'coastaluploads/pexels-inspiredimages-132339.jpg', '2024-08-11 02:33:45'),
(16, 'coastaluploads/pexels-daniel-jurin-358265-2245411.jpg', '2024-08-11 02:34:05'),
(17, 'coastaluploads/pexels-damodigital-1680230.jpg', '2024-08-11 02:34:13'),
(18, 'coastaluploads/pexels-pixabay-417351.jpg', '2024-08-11 02:34:25'),
(19, 'coastaluploads/pexels-japy-975761.jpg', '2024-08-11 02:34:35'),
(20, 'coastaluploads/pexels-vince-2265876.jpg', '2024-08-11 02:34:47'),
(21, 'coastaluploads/pexels-vince-2265880.jpg', '2024-08-11 02:34:56'),
(22, 'coastaluploads/pexels-herman-io-1933116-3584309.jpg', '2024-08-11 02:35:15'),
(23, 'coastaluploads/pexels-souvenirpixels-1571436.jpg', '2024-08-11 02:36:01');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `submitted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `name`, `email`, `message`, `submitted_at`, `timestamp`) VALUES
(1, 'Shahan Iresh', 'shahaniresh@outlook.com', 'I want to know about your photography image size.', '2024-08-10 20:10:54', '2024-08-10 20:10:54'),
(2, 'Esara Prageeth', 'esaraprageeth@gmail.com', 'What is your photography style?', '2024-08-10 20:16:35', '2024-08-10 20:16:35'),
(3, 'Kesara Gayashaan', 'kesaragayashaan@yahoo.com', 'Can I see your portfolio or examples of your previous work?', '2024-08-10 20:17:18', '2024-08-10 20:17:18'),
(4, 'Tharusha Sewindra', 'tharushasewindara@outlook.com', 'What packages do you offer, and what do they include?', '2024-08-10 20:17:44', '2024-08-10 20:17:44'),
(5, 'jhnnjkjnnkjnjk', 'zlvknxvl@gmail.com', 'njnjnjnjnm,no', '2024-08-10 20:18:01', '2024-08-10 20:18:01'),
(6, 'Enuka Geenad', 'enukageenad@outlook.com', 'Do you have experience with similar events or projects?', '2024-08-10 20:18:31', '2024-08-10 20:18:31'),
(7, 'Chethana Bhanuka', 'chethanabhanuka@gmail.com', 'What is your approach to handling unexpected situations?', '2024-08-10 20:19:04', '2024-08-10 20:19:04'),
(8, 'Nayana Monarawila', 'nayana2003@gmail.com', 'How long will it take to receive the final photos?', '2024-08-10 20:19:40', '2024-08-10 20:19:40'),
(9, 'Sanjula Nimsith', 'sanjulanimsith@gmail.com', 'Can I request specific shots or a shot list?', '2024-08-10 20:20:16', '2024-08-10 20:20:16');

-- --------------------------------------------------------

--
-- Table structure for table `landscapeimages`
--

CREATE TABLE `landscapeimages` (
  `id` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `upload_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `landscapeimages`
--

INSERT INTO `landscapeimages` (`id`, `filename`, `upload_time`) VALUES
(10, 'landscapeuploads/landscape4.jpg', '2024-08-10 19:40:47'),
(11, 'landscapeuploads/landscape5.jpg', '2024-08-10 19:41:22'),
(9, 'landscapeuploads/landscape3.jpg', '2024-08-10 19:40:22'),
(7, 'landscapeuploads/landscape1.jpg', '2024-08-10 19:39:13'),
(8, 'landscapeuploads/landscape2.jpg', '2024-08-10 19:39:57'),
(12, 'landscapeuploads/landscape6.jpg', '2024-08-10 19:42:19'),
(13, 'landscapeuploads/landscape7.jpg', '2024-08-10 19:42:48'),
(14, 'landscapeuploads/landscape8.jpg', '2024-08-10 19:44:08'),
(15, 'landscapeuploads/landscape9.jpg', '2024-08-10 19:45:02'),
(16, 'landscapeuploads/landscape10.jpg', '2024-08-10 19:45:16'),
(17, 'landscapeuploads/landscape11.jpg', '2024-08-10 19:45:34'),
(18, 'landscapeuploads/landscape12.jpg', '2024-08-10 19:45:46'),
(19, 'landscapeuploads/landscape13.jpg', '2024-08-10 19:46:02');

-- --------------------------------------------------------

--
-- Table structure for table `receipts`
--

CREATE TABLE `receipts` (
  `id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `details` text NOT NULL,
  `payment_id` varchar(50) NOT NULL,
  `file_path` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `receipts`
--

INSERT INTO `receipts` (`id`, `first_name`, `last_name`, `email`, `contact`, `details`, `payment_id`, `file_path`) VALUES
(1, 'Esara', 'Prageeth', 'esaraprageeth@gmail.com', '0789096672', 'Wedding 2030.05.15 7.00 A.M - 5.00 P.M', '001254865', 'uploads/Esara_Prageeth_001254865_20240808075730.jpg'),
(2, 'Kesara', 'Gayashaan', 'kesaragayashaan@yahoo.com', '0112458865', 'My Birthday 2024.10.31', '0003235689154', 'uploads/Kesara_Gayashaan_0003235689154_20240808080646.jpg'),
(3, 'Tharusha', 'Sewindra', 'tharushasewindara@outlook.com', '0775896325', 'My Anniversary 2024.10.05', '000121654945', 'uploads/Tharusha_Sewindra_000121654945_20240808021549.jpg'),
(4, 'Tharindu', 'Wijethilake', 'tharinduwijwthilake@yahoo.com', '0112458865', '2030.05.14 My wedding I want a Photographer', '00012546459', 'Admin Panel/uploads/Tharindu_Wijethilake_00012546459_20240808154705.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `subscribers`
--

CREATE TABLE `subscribers` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subscribe_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subscribers`
--

INSERT INTO `subscribers` (`id`, `email`, `subscribe_time`) VALUES
(1, 'a58322329@gmail.com', '2024-08-05 17:26:41'),
(2, 'shahaniresh@outlook.com', '2024-08-05 17:32:09'),
(3, 'shashinpunsaraebay@gmail.com', '2024-08-05 17:35:53'),
(4, 'kesaragayashaan@yahoo.com', '2024-08-05 17:38:27'),
(5, 'punsara649@gmail.com', '2024-08-05 17:46:09'),
(6, 'E154631@esoft.academy', '2024-08-05 17:52:45'),
(7, 'shahaniresh2003@outlook.com', '2024-08-06 12:56:25'),
(8, 'admin@far1.onmicrosoft.com', '2024-08-06 12:59:43'),
(9, 'shashinpunsaraebay@gmail.com', '2024-08-06 14:59:23'),
(10, 'ajithironworks71@gmail.com', '2024-08-06 14:59:54'),
(11, 'admin2000@far1.onmicrosoft.com', '2024-08-07 11:16:45'),
(12, 'sahandevinda@gmail.com', '2024-08-07 11:18:14'),
(13, 'shahaniresh2003@outlook.com', '2024-08-08 14:30:49'),
(14, 'tharinduwijwthilake@gmail.com', '2024-08-08 19:41:10'),
(15, 'ajithkumara@gmail.com', '2024-08-09 03:56:39'),
(16, 'tharushasewindara2003@outlook.com', '2024-08-09 18:08:24');

-- --------------------------------------------------------

--
-- Table structure for table `uploads`
--

CREATE TABLE `uploads` (
  `id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `details` text DEFAULT NULL,
  `file_name` varchar(255) NOT NULL,
  `payment_id` varchar(255) NOT NULL,
  `upload_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(6) UNSIGNED NOT NULL,
  `username` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `reg_date`) VALUES
(1, 'Esara Prageeth', 'esaraprageeth@gmail.com', '$2y$10$GPI1zSYJeEb1o3MMalNPcOp1lxhlHKIuxnkhdU/rpNioiJfoxBbA6', '2024-08-05 09:06:09'),
(2, 'Kesara Gayashaan', 'kesaragayashaan@gmail.com', '$2y$10$IVnC..ZWkp0CAjmL.Te7kOuAo4KFllDtV6e1PI1kxuZtKvz8.meN.', '2024-08-05 09:09:48'),
(3, 'Ajith Kumara', 'ajithkumara@gmail.com', '$2y$10$788.OR3X8M9vPsVrT3tCvu5uE9Y6qSP98xnC1410cu0knkJ0e84BK', '2024-08-05 09:11:16'),
(4, 'Tharusha Sewindra', 'tharushasewindra@gmail.com', '$2y$10$/nq8nHF0nJSwuKYROPWcyOXFewg9R5..fVFoeldS.Mt9t2O6bhO3y', '2024-08-05 09:18:29'),
(5, 'Sahan Devinda', 'sahan@gmail.com', '$2y$10$/s5M90XtELdIyMl14H8ZlOqkzbRuBnADFncZnbYYpJs6U7upWE8eq', '2024-08-05 09:20:46'),
(6, 'Tharindu Wijethilake', 'tharindu@yahoo.com', '$2y$10$XLwCAHu982H3GsRnDkW1uOp0bmabejbA9I3Eae7QhE.AjiNlyWfg.', '2024-08-05 09:22:06'),
(7, 'Shahan Iresh', 'shahaniresh@outlook.com', '$2y$10$2Y4Ll5qUnYEehE5hoZW6fOf7ADcKN4RXrogTxb3PS.068PM0PYSny', '2024-08-05 14:16:32'),
(8, 'Yamuna Dhamayanthi', 'yamuna1974@gmail.com', '$2y$10$h/zKSpyjUKPcM2JtCyT4veBGzC7WFKxzBPf.e95b.CfstBHIJkU4m', '2024-08-06 12:46:43'),
(9, 'Tharindu Wijethilake', 'tharinduwijwthilake@yahoo.com', '$2y$10$6p1xCsOQD7hpUwcS2n/7ueOAWUjbTMiMiC2UIqbIpdFupL1mthvAK', '2024-08-08 19:44:48');

-- --------------------------------------------------------

--
-- Table structure for table `wildlifeimages`
--

CREATE TABLE `wildlifeimages` (
  `id` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `upload_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wildlifeimages`
--

INSERT INTO `wildlifeimages` (`id`, `filename`, `upload_time`) VALUES
(7, 'wildlifeuploads/pexels-hendrikcornelissen-2862070.jpg', '2024-08-11 03:06:48'),
(5, 'wildlifeuploads/pexels-leonardo-jarro-204864-633437.jpg', '2024-08-11 03:06:34'),
(6, 'wildlifeuploads/pexels-pixabay-66898.jpg', '2024-08-11 03:06:41'),
(8, 'wildlifeuploads/pexels-pixabay-247373.jpg', '2024-08-11 03:06:57'),
(9, 'wildlifeuploads/pexels-pixabay-52717.jpg', '2024-08-11 03:07:17'),
(10, 'wildlifeuploads/pexels-pixabay-460775.jpg', '2024-08-11 03:07:26'),
(11, 'wildlifeuploads/pexels-couleur-2317904.jpg', '2024-08-11 03:07:46'),
(12, 'wildlifeuploads/pexels-frans-van-heerden-201846-631292.jpg', '2024-08-11 03:07:54'),
(13, 'wildlifeuploads/pexels-pixabay-33045.jpg', '2024-08-11 03:08:07'),
(14, 'wildlifeuploads/pexels-pixabay-460223.jpg', '2024-08-11 03:08:26'),
(15, 'wildlifeuploads/pexels-andreas-barth-89047-1131774.jpg', '2024-08-11 03:08:33'),
(16, 'wildlifeuploads/pexels-andre-mouton-1207875.jpg', '2024-08-11 03:08:42'),
(17, 'wildlifeuploads/pexels-pixabay-36762.jpg', '2024-08-11 03:08:50'),
(18, 'wildlifeuploads/pexels-pixabay-70080.jpg', '2024-08-11 03:09:18'),
(19, 'wildlifeuploads/pexels-creativebin-38994-135940.jpg', '2024-08-11 03:09:26'),
(20, 'wildlifeuploads/pexels-hsapir-1054655.jpg', '2024-08-11 03:09:39'),
(21, 'wildlifeuploads/pexels-pixabay-46254.jpg', '2024-08-11 03:09:46'),
(22, 'wildlifeuploads/pexels-belle-co-99483-847393.jpg', '2024-08-11 03:09:59'),
(23, 'wildlifeuploads/pexels-pixabay-45853.jpg', '2024-08-11 03:10:07'),
(24, 'wildlifeuploads/pexels-pixabay-247376.jpg', '2024-08-11 03:10:14'),
(25, 'wildlifeuploads/pexels-monique-laats-230726-733090.jpg', '2024-08-11 03:10:20'),
(26, 'wildlifeuploads/pexels-thomas-b-270703-814898.jpg', '2024-08-11 03:10:28'),
(27, 'wildlifeuploads/pexels-pixabay-357159.jpg', '2024-08-11 03:10:35');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `coastalimages`
--
ALTER TABLE `coastalimages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `landscapeimages`
--
ALTER TABLE `landscapeimages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `receipts`
--
ALTER TABLE `receipts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscribers`
--
ALTER TABLE `subscribers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uploads`
--
ALTER TABLE `uploads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `wildlifeimages`
--
ALTER TABLE `wildlifeimages`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `coastalimages`
--
ALTER TABLE `coastalimages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `landscapeimages`
--
ALTER TABLE `landscapeimages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `receipts`
--
ALTER TABLE `receipts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `subscribers`
--
ALTER TABLE `subscribers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `uploads`
--
ALTER TABLE `uploads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `wildlifeimages`
--
ALTER TABLE `wildlifeimages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
