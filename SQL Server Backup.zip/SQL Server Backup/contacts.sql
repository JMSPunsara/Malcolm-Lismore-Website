-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql107.byetcluster.com
-- Generation Time: Aug 11, 2024 at 12:00 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_37049035_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `submitted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `name`, `email`, `message`, `submitted_at`, `timestamp`) VALUES
(1, 'Shahan Iresh', 'shahaniresh@outlook.com', 'I want to know about your photography image size.', '2024-08-10 20:10:54', '2024-08-10 20:10:54'),
(2, 'Esara Prageeth', 'esaraprageeth@gmail.com', 'What is your photography style?', '2024-08-10 20:16:35', '2024-08-10 20:16:35'),
(3, 'Kesara Gayashaan', 'kesaragayashaan@yahoo.com', 'Can I see your portfolio or examples of your previous work?', '2024-08-10 20:17:18', '2024-08-10 20:17:18'),
(4, 'Tharusha Sewindra', 'tharushasewindara@outlook.com', 'What packages do you offer, and what do they include?', '2024-08-10 20:17:44', '2024-08-10 20:17:44'),
(5, 'jhnnjkjnnkjnjk', 'zlvknxvl@gmail.com', 'njnjnjnjnm,no', '2024-08-10 20:18:01', '2024-08-10 20:18:01'),
(6, 'Enuka Geenad', 'enukageenad@outlook.com', 'Do you have experience with similar events or projects?', '2024-08-10 20:18:31', '2024-08-10 20:18:31'),
(7, 'Chethana Bhanuka', 'chethanabhanuka@gmail.com', 'What is your approach to handling unexpected situations?', '2024-08-10 20:19:04', '2024-08-10 20:19:04'),
(8, 'Nayana Monarawila', 'nayana2003@gmail.com', 'How long will it take to receive the final photos?', '2024-08-10 20:19:40', '2024-08-10 20:19:40'),
(9, 'Sanjula Nimsith', 'sanjulanimsith@gmail.com', 'Can I request specific shots or a shot list?', '2024-08-10 20:20:16', '2024-08-10 20:20:16');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
