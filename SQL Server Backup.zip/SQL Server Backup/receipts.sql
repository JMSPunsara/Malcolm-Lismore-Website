-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql107.byetcluster.com
-- Generation Time: Aug 11, 2024 at 12:00 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_37049035_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `receipts`
--

CREATE TABLE `receipts` (
  `id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `details` text NOT NULL,
  `payment_id` varchar(50) NOT NULL,
  `file_path` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `receipts`
--

INSERT INTO `receipts` (`id`, `first_name`, `last_name`, `email`, `contact`, `details`, `payment_id`, `file_path`) VALUES
(1, 'Esara', 'Prageeth', 'esaraprageeth@gmail.com', '0789096672', 'Wedding 2030.05.15 7.00 A.M - 5.00 P.M', '001254865', 'uploads/Esara_Prageeth_001254865_20240808075730.jpg'),
(2, 'Kesara', 'Gayashaan', 'kesaragayashaan@yahoo.com', '0112458865', 'My Birthday 2024.10.31', '0003235689154', 'uploads/Kesara_Gayashaan_0003235689154_20240808080646.jpg'),
(3, 'Tharusha', 'Sewindra', 'tharushasewindara@outlook.com', '0775896325', 'My Anniversary 2024.10.05', '000121654945', 'uploads/Tharusha_Sewindra_000121654945_20240808021549.jpg'),
(4, 'Tharindu', 'Wijethilake', 'tharinduwijwthilake@yahoo.com', '0112458865', '2030.05.14 My wedding I want a Photographer', '00012546459', 'Admin Panel/uploads/Tharindu_Wijethilake_00012546459_20240808154705.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `receipts`
--
ALTER TABLE `receipts`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `receipts`
--
ALTER TABLE `receipts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
