-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql107.byetcluster.com
-- Generation Time: Aug 11, 2024 at 12:00 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_37049035_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `coastalimages`
--

CREATE TABLE `coastalimages` (
  `id` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `upload_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `coastalimages`
--

INSERT INTO `coastalimages` (`id`, `filename`, `upload_time`) VALUES
(5, 'coastaluploads/pexels-orlovamaria-4913436.jpg', '2024-08-11 02:29:43'),
(6, 'coastaluploads/pexels-therato-3610763.jpg', '2024-08-11 02:29:51'),
(4, 'coastaluploads/pexels-timmossholder-2969405.jpg', '2024-08-11 02:29:15'),
(7, 'coastaluploads/pexels-pixabay-532891.jpg', '2024-08-11 02:30:05'),
(8, 'coastaluploads/pexels-therato-3451757.jpg', '2024-08-11 02:31:00'),
(9, 'coastaluploads/pexels-inspiredimages-133193.jpg', '2024-08-11 02:31:29'),
(10, 'coastaluploads/pexels-tirachard-kumtanom-112571-584302.jpg', '2024-08-11 02:31:47'),
(11, 'coastaluploads/pexels-therato-3384695.jpg', '2024-08-11 02:32:24'),
(12, 'coastaluploads/pexels-lucianphotography-3566139.jpg', '2024-08-11 02:32:56'),
(13, 'coastaluploads/pexels-miroalt-176383.jpg', '2024-08-11 02:33:18'),
(14, 'coastaluploads/pexels-pixabay-358223.jpg', '2024-08-11 02:33:31'),
(15, 'coastaluploads/pexels-inspiredimages-132339.jpg', '2024-08-11 02:33:45'),
(16, 'coastaluploads/pexels-daniel-jurin-358265-2245411.jpg', '2024-08-11 02:34:05'),
(17, 'coastaluploads/pexels-damodigital-1680230.jpg', '2024-08-11 02:34:13'),
(18, 'coastaluploads/pexels-pixabay-417351.jpg', '2024-08-11 02:34:25'),
(19, 'coastaluploads/pexels-japy-975761.jpg', '2024-08-11 02:34:35'),
(20, 'coastaluploads/pexels-vince-2265876.jpg', '2024-08-11 02:34:47'),
(21, 'coastaluploads/pexels-vince-2265880.jpg', '2024-08-11 02:34:56'),
(22, 'coastaluploads/pexels-herman-io-1933116-3584309.jpg', '2024-08-11 02:35:15'),
(23, 'coastaluploads/pexels-souvenirpixels-1571436.jpg', '2024-08-11 02:36:01');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `coastalimages`
--
ALTER TABLE `coastalimages`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `coastalimages`
--
ALTER TABLE `coastalimages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
