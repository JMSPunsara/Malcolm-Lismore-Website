-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql107.byetcluster.com
-- Generation Time: Aug 11, 2024 at 12:01 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_37049035_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(6) UNSIGNED NOT NULL,
  `username` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `reg_date`) VALUES
(1, 'Esara Prageeth', 'esaraprageeth@gmail.com', '$2y$10$GPI1zSYJeEb1o3MMalNPcOp1lxhlHKIuxnkhdU/rpNioiJfoxBbA6', '2024-08-05 09:06:09'),
(2, 'Kesara Gayashaan', 'kesaragayashaan@gmail.com', '$2y$10$IVnC..ZWkp0CAjmL.Te7kOuAo4KFllDtV6e1PI1kxuZtKvz8.meN.', '2024-08-05 09:09:48'),
(3, 'Ajith Kumara', 'ajithkumara@gmail.com', '$2y$10$788.OR3X8M9vPsVrT3tCvu5uE9Y6qSP98xnC1410cu0knkJ0e84BK', '2024-08-05 09:11:16'),
(4, 'Tharusha Sewindra', 'tharushasewindra@gmail.com', '$2y$10$/nq8nHF0nJSwuKYROPWcyOXFewg9R5..fVFoeldS.Mt9t2O6bhO3y', '2024-08-05 09:18:29'),
(5, 'Sahan Devinda', 'sahan@gmail.com', '$2y$10$/s5M90XtELdIyMl14H8ZlOqkzbRuBnADFncZnbYYpJs6U7upWE8eq', '2024-08-05 09:20:46'),
(6, 'Tharindu Wijethilake', 'tharindu@yahoo.com', '$2y$10$XLwCAHu982H3GsRnDkW1uOp0bmabejbA9I3Eae7QhE.AjiNlyWfg.', '2024-08-05 09:22:06'),
(7, 'Shahan Iresh', 'shahaniresh@outlook.com', '$2y$10$2Y4Ll5qUnYEehE5hoZW6fOf7ADcKN4RXrogTxb3PS.068PM0PYSny', '2024-08-05 14:16:32'),
(8, 'Yamuna Dhamayanthi', 'yamuna1974@gmail.com', '$2y$10$h/zKSpyjUKPcM2JtCyT4veBGzC7WFKxzBPf.e95b.CfstBHIJkU4m', '2024-08-06 12:46:43'),
(9, 'Tharindu Wijethilake', 'tharinduwijwthilake@yahoo.com', '$2y$10$6p1xCsOQD7hpUwcS2n/7ueOAWUjbTMiMiC2UIqbIpdFupL1mthvAK', '2024-08-08 19:44:48');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
